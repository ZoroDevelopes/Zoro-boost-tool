const fs = require('fs-extra');
const readline = require('readline');
const chalk = require('chalk');
const gradient = require('gradient-string');

console.log(gradient.rainbow('\n📋 Discord Joiner Setup Wizard\n'));

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function ask(question) {
    return new Promise((resolve) => {
        rl.question(chalk.blue(`❯ ${question}: `), resolve);
    });
}

async function setup() {
    console.log(chalk.yellow('Fill in the configuration below:\n'));
    
    const config = {
        mode: "tokens",
        captcha_service: "",
        captcha_api_key: "",
        invite: "",
        invite_code_only: false,
        join_delay: 5000,
        boost_delay: 3000,
        retry_attempts: 3,
        retry_delay: 10000,
        use_proxies: false,
        proxy_type: "http",
        rotate_proxies: true,
        max_concurrent: 1,
        boost: {
            enabled: false,
            boost_count: 1,
            use_nitro_boosts: true,
            cancel_existing_subs: true
        },
        logging: {
            verbose: true,
            save_logs: true,
            log_file: "joiner.log"
        },
        safety: {
            humanize_delays: true,
            random_delay_range: 2000,
            timeout: 30000
        }
    };

    // Get invite
    config.invite = await ask('Discord invite (full URL or code)');
    
    // Ask for captcha service
    const useCaptcha = (await ask('Use captcha solver? (y/n)')).toLowerCase() === 'y';
    if (useCaptcha) {
        config.captcha_service = await ask('Captcha service (2captcha/capmonster)');
        config.captcha_api_key = await ask('Captcha API key');
    }
    
    // Ask for boost
    const useBoost = (await ask('Enable server boosting? (y/n)')).toLowerCase() === 'y';
    if (useBoost) {
        config.boost.enabled = true;
        config.boost.serverId = await ask('Server ID to boost');
        config.boost_count = parseInt(await ask('Number of boosts per token (1-2)')) || 1;
    }
    
    // Ask for proxies
    const useProxies = (await ask('Use proxies? (y/n)')).toLowerCase() === 'y';
    config.use_proxies = useProxies;
    
    // Delays
    config.join_delay = parseInt(await ask('Delay between joins (ms) [5000]')) || 5000;
    config.boost_delay = parseInt(await ask('Delay before boost (ms) [3000]')) || 3000;

    // Save config
    await fs.writeJson('config.json', config, { spaces: 2 });
    
    console.log(chalk.green('\n✅ Configuration saved to config.json'));
    
    // Check for tokens.txt
    if (!fs.existsSync('tokens.txt')) {
        console.log(chalk.yellow('\n⚠  Please add your Discord tokens to tokens.txt'));
        console.log(chalk.gray('   One token per line'));
    }
    
    // Check for proxies.txt if needed
    if (useProxies && !fs.existsSync('proxies.txt')) {
        console.log(chalk.yellow('\n⚠  Please add your proxies to proxies.txt'));
        console.log(chalk.gray('   Format: http://user:pass@ip:port or http://ip:port'));
    }
    
    rl.close();
    console.log(chalk.green('\n🎉 Setup complete! Run "npm start" to begin.'));
}

setup();