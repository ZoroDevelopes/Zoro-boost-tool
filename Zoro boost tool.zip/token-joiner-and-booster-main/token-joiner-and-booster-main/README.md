# Discord Server Joiner & Booster v2.0

Advanced Discord server joiner with boosting capabilities, proxy support, and captcha solving.

## ✨ Features
- Multi-token server joining
- Server boosting (2 boosts per token max)
- Proxy rotation support
- Captcha solving (2captcha/CapMonster)
- Advanced logging system
- Human-like delays for safety
- Concurrent processing
- Error handling & retry system

## 🚀 Installation

1. **Install Node.js** (v16.9.0 or higher)
   - Download from [nodejs.org](https://nodejs.org/)

2. **Clone/Download the project**
   ```bash
   git clone https://github.com/yourusername/discord-joiner.git
   cd discord-joiner