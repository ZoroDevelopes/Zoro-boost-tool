const chalk = require('chalk');
const gradient = require('gradient-string');
const fs = require('fs-extra');
const path = require('path');
const { Client } = require('discord.js-selfbot-v13');
const { HttpsProxyAgent } = require('https-proxy-agent');
const ora = require('ora');
const readline = require('readline');

// Banner
console.log(gradient.rainbow(`
╔══════════════════════════════════════════════════╗
║   DISCORD SERVER JOINER & BOOSTER v2.0          ║
║           Enhanced & Working Version            ║
║                                                  ║
║    • Multi-token support                        ║
║    • Proxy rotation                            ║
║    • Captcha solving                           ║
║    • Server boosting                           ║
║    • Advanced logging                          ║
╚══════════════════════════════════════════════════╝
`));

// Error handling
process.on('unhandledRejection', (reason, promise) => {
    console.log(chalk.red(`[ERROR] Unhandled Rejection:`));
    console.log(chalk.gray(reason.stack || reason));
});

process.on('uncaughtException', (err) => {
    console.log(chalk.red(`[CRITICAL] Uncaught Exception:`));
    console.log(chalk.gray(err.stack));
});

// Configuration
const config = require('./config.json');
const logs = [];

// Stats
const stats = {
    total: 0,
    success: 0,
    failed: 0,
    boosted: 0,
    startTime: Date.now()
};

class Logger {
    static log(message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const types = {
            success: chalk.green('✓'),
            error: chalk.red('✗'),
            info: chalk.blue('ℹ'),
            warning: chalk.yellow('⚠'),
            boost: chalk.magenta('⚡')
        };
        
        const logMessage = `[${timestamp}] ${types[type] || types.info} ${message}`;
        console.log(logMessage);
        
        if (config.logging.save_logs) {
            logs.push(logMessage.replace(/\u001b\[.*?m/g, ''));
            if (logs.length > 1000) {
                logs.shift();
            }
        }
    }

    static saveLogs() {
        if (config.logging.save_logs && logs.length > 0) {
            fs.appendFileSync(config.logging.log_file, logs.join('\n') + '\n');
        }
    }
}

class TokenManager {
    static async loadTokens() {
        try {
            const content = await fs.readFile('tokens.txt', 'utf-8');
            return content
                .split('\n')
                .map(t => t.trim())
                .filter(t => t.length > 0 && t !== 'token1' && t !== 'token2');
        } catch (err) {
            Logger.log('tokens.txt not found or empty', 'error');
            return [];
        }
    }

    static validateToken(token) {
        return token && token.length > 50 && token.includes('.');
    }
}

class ProxyManager {
    static proxies = [];
    static currentIndex = 0;

    static async loadProxies() {
        try {
            const content = await fs.readFile('proxies.txt', 'utf-8');
            this.proxies = content
                .split('\n')
                .map(p => p.trim())
                .filter(p => p.length > 0 && !p.includes('username:password@ip:port'))
                .map(p => {
                    if (!p.startsWith('http://') && !p.startsWith('https://')) {
                        return `http://${p}`;
                    }
                    return p;
                });
            
            Logger.log(`Loaded ${this.proxies.length} proxies`, 'info');
            return this.proxies.length > 0;
        } catch (err) {
            Logger.log('No proxies.txt found or empty', 'warning');
            return false;
        }
    }

    static getNextProxy() {
        if (this.proxies.length === 0) return null;
        
        if (config.rotate_proxies) {
            const proxy = this.proxies[this.currentIndex];
            this.currentIndex = (this.currentIndex + 1) % this.proxies.length;
            return proxy;
        } else {
            return this.proxies[Math.floor(Math.random() * this.proxies.length)];
        }
    }
}

class DiscordBot {
    constructor(token, proxy = null) {
        this.token = token;
        this.proxy = proxy;
        this.client = null;
        this.isLoggedIn = false;
        this.userTag = '';
    }

    async initialize() {
        const options = {
            checkUpdate: false,
            restRequestTimeout: 60000,
            captchaKey: config.captcha_api_key || null,
            captchaService: config.captcha_service || null
        };

        // Add proxy if configured
        if (config.use_proxies && this.proxy) {
            try {
                options.http = { agent: new HttpsProxyAgent(this.proxy) };
                Logger.log(`Using proxy: ${this.proxy.split('@').pop() || this.proxy}`, 'info');
            } catch (err) {
                Logger.log(`Failed to setup proxy: ${err.message}`, 'error');
            }
        }

        this.client = new Client(options);
        
        // Setup event handlers
        this.setupEventHandlers();
        
        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                reject(new Error('Login timeout'));
            }, config.safety.timeout);

            this.client.once('ready', () => {
                clearTimeout(timeout);
                this.isLoggedIn = true;
                this.userTag = this.client.user.tag;
                resolve(true);
            });

            this.client.login(this.token).catch(reject);
        });
    }

    setupEventHandlers() {
        this.client.on('disconnect', () => {
            Logger.log(`Disconnected: ${this.userTag}`, 'warning');
            this.isLoggedIn = false;
        });

        this.client.on('error', (err) => {
            Logger.log(`Client error for ${this.userTag}: ${err.message}`, 'error');
        });
    }

    async joinServer(inviteCode) {
        try {
            Logger.log(`Attempting to join server with ${this.userTag}...`, 'info');
            
            const invite = await this.client.fetchInvite(inviteCode);
            await invite.acceptInvite(true);
            
            Logger.log(`Successfully joined server as ${this.userTag}`, 'success');
            return true;
        } catch (err) {
            Logger.log(`Failed to join with ${this.userTag}: ${err.message}`, 'error');
            return false;
        }
    }

    async boostServer(serverId, boostCount = 1) {
        if (!config.boost.enabled) return false;

        try {
            Logger.log(`Preparing to boost server with ${this.userTag}...`, 'boost');
            
            // Fetch available boosts
            const billing = await this.client.billing.fetchGuildBoosts();
            const availableBoosts = Array.from(billing.values());
            
            if (availableBoosts.length === 0) {
                Logger.log(`No boosts available for ${this.userTag}`, 'warning');
                return false;
            }

            // Cancel existing subscriptions if configured
            if (config.boost.cancel_existing_subs) {
                for (const boost of availableBoosts) {
                    try {
                        await boost.unsubscribe();
                        Logger.log(`Cancelled existing subscription for ${this.userTag}`, 'info');
                    } catch (err) {
                        // Ignore errors if not subscribed
                    }
                }
            }

            // Wait a bit before subscribing
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Subscribe to target server
            let boostedCount = 0;
            for (const boost of availableBoosts.slice(0, boostCount)) {
                try {
                    await boost.subscribe(serverId);
                    boostedCount++;
                    Logger.log(`Boost ${boostedCount} applied by ${this.userTag}`, 'boost');
                    await new Promise(resolve => setTimeout(resolve, 500));
                } catch (err) {
                    Logger.log(`Failed to apply boost with ${this.userTag}: ${err.message}`, 'error');
                }
            }

            return boostedCount > 0;
        } catch (err) {
            Logger.log(`Boost error for ${this.userTag}: ${err.message}`, 'error');
            return false;
        }
    }

    async destroy() {
        if (this.client && this.isLoggedIn) {
            try {
                this.client.destroy();
                Logger.log(`Logged out: ${this.userTag}`, 'info');
            } catch (err) {
                // Ignore destroy errors
            }
        }
    }
}

class JoinerManager {
    constructor() {
        this.activeBots = [];
        this.isRunning = false;
        this.spinner = null;
    }

    async start() {
        Logger.log('Starting joiner process...', 'info');
        
        // Load tokens and proxies
        const tokens = await TokenManager.loadTokens();
        const hasProxies = await ProxyManager.loadProxies();
        
        if (tokens.length === 0) {
            Logger.log('No valid tokens found in tokens.txt', 'error');
            return;
        }

        Logger.log(`Loaded ${tokens.length} tokens`, 'success');
        stats.total = tokens.length;

        // Parse invite code
        let inviteCode = config.invite;
        if (!config.invite_code_only && config.invite.includes('/')) {
            const match = config.invite.match(/\/([^/]+)$/);
            inviteCode = match ? match[1] : config.invite;
        }

        if (!inviteCode) {
            Logger.log('Invalid invite code', 'error');
            return;
        }

        this.isRunning = true;
        this.spinner = ora('Processing tokens...').start();

        // Process tokens sequentially
        for (let i = 0; i < tokens.length && this.isRunning; i++) {
            const token = tokens[i];
            
            if (!TokenManager.validateToken(token)) {
                Logger.log(`Invalid token format at line ${i + 1}`, 'warning');
                stats.failed++;
                continue;
            }

            this.spinner.text = `Processing token ${i + 1}/${tokens.length}`;
            
            // Get proxy for this token
            const proxy = config.use_proxies && hasProxies ? ProxyManager.getNextProxy() : null;
            
            // Create and initialize bot
            const bot = new DiscordBot(token, proxy);
            
            try {
                // Initialize bot
                await bot.initialize();
                
                // Add human-like delay if enabled
                if (config.safety.humanize_delays) {
                    const randomDelay = Math.random() * config.safety.random_delay_range;
                    await new Promise(resolve => setTimeout(resolve, config.join_delay + randomDelay));
                } else {
                    await new Promise(resolve => setTimeout(resolve, config.join_delay));
                }

                // Join server
                const joined = await bot.joinServer(inviteCode);
                
                if (joined) {
                    stats.success++;
                    
                    // Boost server if enabled
                    if (config.boost.enabled && config.boost.serverId) {
                        await new Promise(resolve => setTimeout(resolve, config.boost_delay));
                        
                        const boosted = await bot.boostServer(
                            config.boost.serverId,
                            config.boost.boost_count
                        );
                        
                        if (boosted) {
                            stats.boosted++;
                        }
                    }
                } else {
                    stats.failed++;
                }

                // Update spinner
                this.spinner.text = `Success: ${stats.success} | Failed: ${stats.failed} | Boosted: ${stats.boosted}`;

            } catch (err) {
                Logger.log(`Error with token ${i + 1}: ${err.message}`, 'error');
                stats.failed++;
            } finally {
                // Clean up
                await bot.destroy();
                this.activeBots = this.activeBots.filter(b => b !== bot);
                
                // Small delay between tokens
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }

        this.spinner.stop();
        this.showStats();
        this.isRunning = false;
    }

    stop() {
        this.isRunning = false;
        Logger.log('Stopping joiner...', 'warning');
        
        // Destroy all active bots
        this.activeBots.forEach(async bot => {
            await bot.destroy();
        });
        
        this.activeBots = [];
        
        if (this.spinner) {
            this.spinner.stop();
        }
    }

    showStats() {
        const runtime = Math.floor((Date.now() - stats.startTime) / 1000);
        const minutes = Math.floor(runtime / 60);
        const seconds = runtime % 60;
        
        console.log('\n' + gradient.passion('═'.repeat(50)));
        console.log(gradient.rainbow('         PROCESS COMPLETED - STATISTICS         '));
        console.log(gradient.passion('═'.repeat(50)));
        console.log(chalk.cyan(`Total Tokens:        ${stats.total}`));
        console.log(chalk.green(`Successful Joins:    ${stats.success}`));
        console.log(chalk.red(`Failed Joins:        ${stats.failed}`));
        console.log(chalk.magenta(`Boosted Servers:     ${stats.boosted}`));
        console.log(chalk.yellow(`Success Rate:        ${((stats.success / stats.total) * 100).toFixed(2)}%`));
        console.log(chalk.blue(`Runtime:             ${minutes}m ${seconds}s`));
        console.log(gradient.passion('═'.repeat(50)) + '\n');
        
        // Save logs
        Logger.saveLogs();
    }
}

// Main execution
async function main() {
    const joiner = new JoinerManager();
    
    // Handle Ctrl+C
    process.on('SIGINT', () => {
        joiner.stop();
        Logger.log('Shutting down...', 'warning');
        process.exit(0);
    });

    try {
        await joiner.start();
    } catch (err) {
        Logger.log(`Fatal error: ${err.message}`, 'error');
        process.exit(1);
    }
}

// Run the bot
if (require.main === module) {
    main();
}

module.exports = { DiscordBot, JoinerManager, Logger };